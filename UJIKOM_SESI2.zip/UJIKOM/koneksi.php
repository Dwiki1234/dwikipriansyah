<?php
// file config.php

$conn=mysqli_connect("localhost","root","","db_penjualan");
?>