<?php
include "koneksi.php";

$nama = $_POST['nama'];
$telp = $_POST['telp'];
$alamat=$_POST['alamat'];

		//perintah query SQL
$query = "INSERT into supplier(nama_supplier,no_telp,alamat) Values('$nama','$telp','$alamat')";

		//perintah menjalankan query sql pada php
		$perintah = mysqli_query($conn, $query);

		if($perintah)
		{
			echo "Data sukses tersimpan pada database";
			header("location:supplier_tampil.php");
		}else
		{
			echo "Data Gagal Tersimpan";
		}


?>