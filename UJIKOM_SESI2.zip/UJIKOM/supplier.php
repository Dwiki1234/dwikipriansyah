
<form method="post" action="supplier_proses.php">
<table>
<tr>
	<td colspan="2" align="center">FORM DATA SUPPLIER</td>
</tr>
	<tr>
		<td>Nama Supplier</td>
		<td><input type="text" size="50" name="nama"placeholder="Nama Supplier"></td>
	</tr>
	<tr>
		<td>No Telp</td>
		<td><input type="text" size="50" name="telp"placeholder="Nomor Telepon"></td>
	</tr>
	<tr>
		<td>Alamat</td>
		<td><input type="text" size="50" name="alamat"placeholder="Alamat"></td>
	</tr>
<tr>
	<td colspan="2" align="right"><input type="submit" value="SIMPAN" ></td>
</tr>
</table>

</form>